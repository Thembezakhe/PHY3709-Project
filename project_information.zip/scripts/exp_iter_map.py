from pylab import *

def main():
    n = 100
    alpha = 1.1
    x_values = zeros(n,'d')  # create a vecore of n zeros
    x_values[0] = 0.5        # set the first value
    for i in range(n-1):
        x_values[i+1] = alpha*x_values[i]
    #
    fig = figure(figsize =(10,7))
    #fig.text(0.7,0.30,r'$N=40$',fontsize=26)
    ax = fig.add_subplot(111)      
    ax.set_xlabel(r'$ i $',size=32)
    ax.set_ylabel(r'$ x_i  $',size=32)
    ax.grid(False)
    xticks(size=20)
    yticks(size=20)
    xlim(0,100)
    #ylim(0,1)
    ax.plot(range(n),x_values,label=r'$x_n$')
    ax.plot(range(n),x_values[0]*exp(0.0951*arange(n)),'--',linewidth=2,label=r'$0.5\exp(0.0951\times i)$')
    ax.legend(loc=(0.3,0.55), prop={'size':26},frameon=False)
    print(log(alpha))
    savefig('fig1.pdf', dpi=300)
    show()


main()
