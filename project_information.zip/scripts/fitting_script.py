from pylab import linspace,sqrt,dot,concatenate,zeros,loadtxt,plot,show
from scipy.optimize import leastsq
#
def ef(v,x,y,z,c,xdata,ydata):
    '''
     Residual (error function)
    '''
    x[0] = v[1]; y[0] = v[2]
    for i in range(len(xdata)):
        y[i+1] = v[0]*y[i]*(z[i]-x[i])/z[0]
        x[i+1] = x[i] + y[i+1]
        z[i+1] = z[i] - c*y[i]
    er = concatenate(((x[0:-1]-xdata)/xdata,(y[0:-1]-ydata)/ydata))
    return er
#
def main():
    f = loadtxt('South Africa.dat') # your data file
    xdata = f[100:180,1]  # select range of data here
    ydata = f[100:180,2]  
    c = 0.035           # set fraction of deaths/confirmed cases
    print(c)
    n = len(xdata)+1    # number of data points
    m = int(f[0,0])     # day of first data point
    #
    x = zeros(n,'d') # for storing total cases
    y = zeros(n,'d') # for storing new cases
    z = zeros(n,'d') # for storing total population
    #
    x[0] = xdata[0]     # initial guess -- to be optimized
    y[0] = ydata[0]     # initial guess -- to be optimized
    z[0] = 58.0e6       # estimated total population for country
    #
    v0 = zeros(3,'d') # quantities to be be optimised
    v0[0] = 1.14      # initial guess for alpha
    v0[1] = x[0]
    v0[2] = y[0]
    #
    v,mesg = leastsq(ef,v0,args=(x[0:n],y[0:n],z[0:n],c,xdata,ydata),ftol=1e-13,maxfev=500)
    #
    x[0] = v[1]
    y[0] = v[2]
    for i in range(len(xdata)):
        y[i+1] = v[0]*y[i]*(z[i]-x[i])/z[0]
        x[i+1] = x[i] + y[i+1]
        z[i+1] = z[i] - c*y[i]
    plot(x)
    plot(xdata,'^',ms=3)
    show()


if __name__ == "__main__":
    main()
