from pylab import *
from csv import reader

def readcountry(filename,country):
    with open(filename, newline="") as f:
        for row in reader(f):
            if row[0] == '' and row[1] == country:
                return row


    
def main():
    country_name = "South Africa"   # set country name
    confirmed = readcountry('time_series_covid19_confirmed_global.csv',country_name)
    deaths = readcountry('time_series_covid19_deaths_global.csv',country_name)
    recovered = readcountry('time_series_covid19_recovered_global.csv',country_name)
    print(deaths[0:4])    # check if the country was read in correctly
    outfile = open(country_name+'.dat','w')
    for i in range(4,len(confirmed)-1,1):
        outfile.write('%12i' % int(i-4))
        outfile.write('%12i' % int(confirmed[i]))
        outfile.write('%12i' % (int(confirmed[i+1])-int(confirmed[i])))
        outfile.write('%12i' % (int(deaths[i+1])-int(deaths[i])))
        outfile.write('\n')
    outfile.close()
    daily = []
    for i in range(4,len(confirmed)-1,1):
        daily.append(int(confirmed[i+1])-int(confirmed[i]))
    plot(daily)
    show()
main()
